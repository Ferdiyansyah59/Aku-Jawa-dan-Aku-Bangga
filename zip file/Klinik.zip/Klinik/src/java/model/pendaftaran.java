/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author ferdi
 */
public class pendaftaran {
    private String noantri;
    private String idpasien;
    private String idpoli;
    private String tgl;
    private String keterangan;
    private String namadokter;
    private String id_dokter;
    private String user_id;
    private String waktu;
    private String namapasien;
    private String namapoli;

    public String getNoantri() {
        return noantri;
    }

    public void setNoantri(String noantri) {
        this.noantri = noantri;
    }

    public String getIdpasien() {
        return idpasien;
    }

    public void setIdpasien(String idpasien) {
        this.idpasien = idpasien;
    }

    public String getIdpoli() {
        return idpoli;
    }

    public void setIdpoli(String idpoli) {
        this.idpoli = idpoli;
    }

    public String getTgl() {
        return tgl;
    }

    public void setTgl(String tgl) {
        this.tgl = tgl;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

    public String getNamadokter() {
        return namadokter;
    }

    public void setNamadokter(String namadokter) {
        this.namadokter = namadokter;
    }

    public String getId_dokter() {
        return id_dokter;
    }

    public void setId_dokter(String id_dokter) {
        this.id_dokter = id_dokter;
    }

    public String getNamapasien() {
        return namapasien;
    }

    public void setNamapasien(String namapasien) {
        this.namapasien = namapasien;
    }

    public String getNamapoli() {
        return namapoli;
    }

    public void setNamapoli(String namapoli) {
        this.namapoli = namapoli;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }
    
    
}
