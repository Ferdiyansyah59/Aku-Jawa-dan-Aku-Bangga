/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author ferdi
 */
public class rawatinap {
    private String idrawat;
    private String idpasien;
    private String idkamar;
    private String namapasien;
    private String namaruang;
    private String tglcekin;
    private String tglcekout;
    private String keterangan;

    public String getIdrawat() {
        return idrawat;
    }

    public void setIdrawat(String idrawat) {
        this.idrawat = idrawat;
    }

    public String getIdpasien() {
        return idpasien;
    }

    public void setIdpasien(String idpasien) {
        this.idpasien = idpasien;
    }

    public String getIdkamar() {
        return idkamar;
    }

    public void setIdkamar(String idkamar) {
        this.idkamar = idkamar;
    }

    public String getNamapasien() {
        return namapasien;
    }

    public void setNamapasien(String namapasien) {
        this.namapasien = namapasien;
    }

    public String getNamaruang() {
        return namaruang;
    }

    public void setNamaruang(String namaruang) {
        this.namaruang = namaruang;
    }

    public String getTglcekin() {
        return tglcekin;
    }

    public void setTglcekin(String tglcekin) {
        this.tglcekin = tglcekin;
    }

    public String getTglcekout() {
        return tglcekout;
    }

    public void setTglcekout(String tglcekout) {
        this.tglcekout = tglcekout;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }
    
    
}
