/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author ferdi
 */
import connection.koneksi;
import model.resep;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
public class resepDao {
    private final Connection con;
    private PreparedStatement stm;
    private ResultSet res;
    
    final String getData = "SELECT resep.*, detail_resep.*, dokter.nama_dokter, poli.nama_poli FROM resep, detail_resep, dokter, poli ORDER BY resep.id_resep";
    final String postResep = "INSERT INTO resep (id_resep, id_dokter, tgl_resep, id_poli, user_id, waktu) VALUES (?,?,?,?,?,?)";
    final String postDetail = "INSERT INTO detail_resep (id_resep, id_obat, harga, jumlah, keterangan, user_id, waktu)VALUES(?,?,?,?,?,?,?)";
    final String putResep = "UPDATE resep SET id_dokter=?, tgl_resep=?, id_poli=?, user_id=?, waktu=? WHERE id_resep=?";
    final String putDetail = "UPDATE detail_resep SET  id_obat=?, harga=?, jumlah=?, keterangan=?, user_id=?, waktu=? WHERE id_resep=?";
    final String deleteResep = "DELETE FROM resep WHERE id_resep";
    final String deleteDetail = "DELETE FROM detail_resep WHERE id_resep";
    
    public resepDao(){
        con = koneksi.getKoneksi();
    }
    
    public ArrayList<resep>getAllResep(){
        ArrayList<resep>listResep = new ArrayList();
        try{
            stm = con.prepareStatement(getData);
            res = stm.executeQuery();
            while(res.next()){
                resep awa = new resep();
                awa.setId_resep(res.getString("resep.id_resep"));
                awa.setId_dokter(res.getString("id_dokter"));
                awa.setId_resep(res.getString("id_resep"));
                awa.setId_poli(res.getString("id_poli"));
                awa.setUser_id(res.getString("resep.user_id"));
                awa.setWaktu(res.getString("resep.waktu"));
                awa.setId_obat(res.getString("id_obat"));
                awa.setHarga(res.getString("harga"));
                awa.setJumlah(res.getString("jumlah"));
                awa.setKeterangan(res.getString("keterangan"));
                awa.setUserid(res.getString("detail_resep.user_id"));
                awa.setWaktuDetail(res.getString("detail_resep.waktu"));
                awa.setNama_dokter(res.getString("nama_dokter"));
                awa.setNama_poli(res.getString("nama_poli"));
                listResep.add(awa);
            }
        }catch(SQLException e){
            System.err.println("Kesalahan di get "+e);
        }
        return listResep;
    }
    
    public void  simpanResep(resep awa){
        try{
            stm = con.prepareStatement(postResep);
            stm.setString(1, awa.getId_resep());
            stm.setString(2, awa.getId_dokter());
            stm.setString(3, awa.getTgl_resep());
            stm.setString(4, awa.getId_poli());
            stm.setString(5, awa.getUser_id());
            stm.setString(6, awa.getWaktu());
            stm.executeUpdate();
        }catch(SQLException e){
            System.err.println("Eror di simpan resep "+e);
        }
    }
    
    public void simpanDetail(resep awa){
        try{
            stm = con.prepareStatement(postDetail);
            stm.setString(1, awa.getId_resep());
            stm.setString(2, awa.getId_obat());
            stm.setString(3, awa.getHarga());
            stm.setString(4, awa.getJumlah());
            stm.setString(5, awa.getKeterangan());
            stm.setString(6, awa.getUserid());
            stm.setString(7, awa.getWaktuDetail());
            stm.executeUpdate();
        }catch(SQLException e){
            System.err.println("Eror di simpan detail "+e);
        }
    }
    
    public void editResep(resep awa){
        try{
            stm = con.prepareStatement(putResep);
            stm.setString(1, awa.getId_dokter());
            stm.setString(2, awa.getTgl_resep());
            stm.setString(3, awa.getId_poli());
            stm.setString(4, awa.getUser_id());
            stm.setString(5, awa.getWaktu());
            stm.setString(6, awa.getId_resep());
            stm.executeUpdate();
        }catch(SQLException e){
            System.err.println("Eror di edit resep "+e);
        }
    }
    
    public void editDetail(resep awa){
        try{
            stm = con.prepareStatement(putDetail);
            stm.setString(1, awa.getId_obat());
            stm.setString(2, awa.getHarga());
            stm.setString(3, awa.getJumlah());
            stm.setString(4, awa.getKeterangan());
            stm.setString(5, awa.getUserid());
            stm.setString(6, awa.getWaktuDetail());
            stm.setString(7, awa.getId_resep());       
            stm.executeUpdate();
        }catch(SQLException e){
            System.err.println("Eror di edit detail "+e);
        }
    }
    
    public void hapusResep(String id_resep){
        try{
            stm = con.prepareStatement(deleteResep);
            stm.setString(1, id_resep);
            stm.executeUpdate();
        }catch(SQLException e){
            System.err.println("Eror di hapus Resep "+e);
        }
    }
    
    public void hapusDetail(String id_resep){
        try{
            stm = con.prepareStatement(deleteDetail);
            stm.setString(1, id_resep);
            stm.executeUpdate();
        }catch(SQLException e){
            System.err.println("Eror di hapus Detail "+e);
        }
    }
}
