/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author ferdi
 */
import connection.koneksi;
import model.pendaftaran;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
public class pendaftaranDao {
    private final Connection Koneksi;
    private PreparedStatement preStmt;
    private ResultSet rs;
    private final SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
//    private Object Koneksi;
    public pendaftaranDao(){
        Koneksi=koneksi.getKoneksi();
    }
    
    public ArrayList<pendaftaran> getAllpendaftaran(){
        ArrayList<pendaftaran> listpendaftaran=new ArrayList<>();
        try{
            String sqlAlldaftar="SELECT  pendaftaran.*, dokter.nama_dokter, poli.nama_poli FROM pendaftaran, dokter, poli ORDER BY no_antrian";
            preStmt = Koneksi.prepareStatement(sqlAlldaftar);
            rs = preStmt.executeQuery();
            while(rs.next()){
                pendaftaran daftar = new pendaftaran();
                daftar.setNoantri(rs.getString("no_antrian"));
                daftar.setIdpasien(rs.getString("id_pasien"));
                daftar.setIdpoli(rs.getString("id_poli"));
                daftar.setNamapoli(rs.getString("nama_poli"));
                daftar.setTgl(rs.getString("tgl_daftar"));
                daftar.setKeterangan(rs.getString("keterangan"));
                daftar.setNamadokter(rs.getString("namadokter"));
                listpendaftaran.add(daftar);
            }  
        }catch(SQLException se){
            System.out.println("ada kesalahan 1 : " +se);
        }
        return listpendaftaran;
    }
    
    public void simpanData (pendaftaran daftar, String page){
        String sqlSimpan = null;
        if (page.equals("edit")){
            sqlSimpan = "UPDATE pendaftaran SET id_pasien=?, id_poli=?,  tgl_daftar=?, "
                    + "keterangan=?, user_id=?, waktu=?,  id_dokter=? where no_antrian=?";
        }
        else if (page.equals("tambah")){
            sqlSimpan = "INSERT INTO pendaftaran (id_pasien, id_poli,  tgl_daftar,"
                    + "keterangan, user_id, waktu,  id_adokter ) values (?,?,?,?,?,?,?,?)";
        }
        try{
            preStmt=Koneksi.prepareStatement(sqlSimpan);
            preStmt.setString(1, daftar.getIdpasien());
            preStmt.setString(2, daftar.getIdpoli());
            preStmt.setString(3, daftar.getTgl());
            preStmt.setString(4, daftar.getKeterangan());
            preStmt.setString(5, daftar.getUser_id());
            preStmt.setString(6, daftar.getWaktu());
            preStmt.setString(7, daftar.getId_dokter());
            preStmt.setString(8, daftar.getNoantri());
            preStmt.executeUpdate();
        }catch (SQLException se){
            System.out.println("Ada Kesalahan 2 : " + se);
        }
    }
    
    public void hapusData(String noantri){
        String sqlHapus = "delete from pendaftaran where no_antrian=? ";
        try{
            preStmt=Koneksi.prepareStatement(sqlHapus);
            preStmt.setString(1, noantri);
            preStmt.executeUpdate();
        }
        catch (SQLException se){
            System.out.println("Salah disini : " + se);
        }
    }
    
}
