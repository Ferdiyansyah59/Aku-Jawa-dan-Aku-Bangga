/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author ferdiyansyah
 */
public class anggota {
    private String noanggota;
    private String nama;
    private String tmplahir;
    private String tgllahir;
    private String alamat;
    private String telepon;
    private String gender;

    public String getNoanggota() {
        return noanggota;
    }

    public void setNoanggota(String noanggota) {
        this.noanggota = noanggota;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getTmplahir() {
        return tmplahir;
    }

    public void setTmplahir(String tmplahir) {
        this.tmplahir = tmplahir;
    }

    public String getTgllahir() {
        return tgllahir;
    }

    public void setTgllahir(String tgllahir) {
        this.tgllahir = tgllahir;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getTelepon() {
        return telepon;
    }

    public void setTelepon(String telepon) {
        this.telepon = telepon;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    
}
