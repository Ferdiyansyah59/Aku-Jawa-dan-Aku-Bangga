/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author ferdiyansyah
 */
public class pinjaman {
    private String nopinjaman;
    private String noanggota;
    private String tglpinjaman;
    private String pokokpinjaman;
    private String bungapinjaman;
    private String lamapinjaman;
    private String angsuranpokok;
    private String angsuranbunga;
    private String accpetugas;
    private String namaAnggota;
    private String nik;
    private String namapetugas;

    public String getNik() {
        return nik;
    }

    public void setNik(String nik) {
        this.nik = nik;
    }

    public String getNamapetugas() {
        return namapetugas;
    }

    public void setNamapetugas(String namapetugas) {
        this.namapetugas = namapetugas;
    }
    

    public String getNamaAnggota() {
        return namaAnggota;
    }

    public void setNamaAnggota(String namaAnggota) {
        this.namaAnggota = namaAnggota;
    }

    public String getNopinjaman() {
        return nopinjaman;
    }

    public void setNopinjaman(String nopinjaman) {
        this.nopinjaman = nopinjaman;
    }

    public String getNoanggota() {
        return noanggota;
    }

    public void setNoanggota(String noanggota) {
        this.noanggota = noanggota;
    }

    public String getTglpinjaman() {
        return tglpinjaman;
    }

    public void setTglpinjaman(String tglpinjaman) {
        this.tglpinjaman = tglpinjaman;
    }

    public String getPokokpinjaman() {
        return pokokpinjaman;
    }

    public void setPokokpinjaman(String pokokpinjaman) {
        this.pokokpinjaman = pokokpinjaman;
    }

    public String getBungapinjaman() {
        return bungapinjaman;
    }

    public void setBungapinjaman(String bungapinjaman) {
        this.bungapinjaman = bungapinjaman;
    }

    public String getLamapinjaman() {
        return lamapinjaman;
    }

    public void setLamapinjaman(String lamapinjaman) {
        this.lamapinjaman = lamapinjaman;
    }

    public String getAngsuranpokok() {
        return angsuranpokok;
    }

    public void setAngsuranpokok(String angsuranpokok) {
        this.angsuranpokok = angsuranpokok;
    }

    public String getAngsuranbunga() {
        return angsuranbunga;
    }

    public void setAngsuranbunga(String angsuranbunga) {
        this.angsuranbunga = angsuranbunga;
    }

    public String getAccpetugas() {
        return accpetugas;
    }

    public void setAccpetugas(String accpetugas) {
        this.accpetugas = accpetugas;
    }
}
