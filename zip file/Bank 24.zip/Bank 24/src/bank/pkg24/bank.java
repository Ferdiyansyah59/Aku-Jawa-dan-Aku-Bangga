/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank.pkg24;

/**
 *
 * @author ferdiyansyah
 */
public interface bank {
    
    public void menabung(double tb);
    public void transfer();
    public void menarik();
    
}
